+++++++++++++DESCRIPTION+++++++++++

A self-initiative project for practice purposes. The website is made in HTML and CSS with the introduction of Bootstrap and simple JS and Jquery. The website contains a total of 3 pages and serves as a simple template for certain purposes. Simply unzip and enter the "Index" page with your default browser.


By Nikola Jocic

